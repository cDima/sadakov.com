This files are taken from original entypo 2.0, with minor changes:

1. TTF
  - changed descent to 0, accent to 500, to fix scale
  - autofixed missed points in FontForge
2. SVG
  - converted from TTF

Sources: http://www.entypo.com/
